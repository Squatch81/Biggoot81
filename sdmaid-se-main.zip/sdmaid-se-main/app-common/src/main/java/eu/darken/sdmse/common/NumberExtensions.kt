package eu.darken.sdmse.common

fun Int.toOctal(): String {
    return Integer.toOctalString(this)
}