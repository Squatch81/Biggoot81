package eu.darken.sdmse.common.funnel


class IPCBufferException(message: String) : RuntimeException(message)
