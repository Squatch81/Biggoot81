package eu.darken.sdmse.common

object SdmSeLinks {
    const val ISSUES = "https://github.com/d4rken-org/sdmaid-se/issues"
    const val PRIVACY_POLICY = "https://github.com/d4rken-org/sdmaid-se/blob/main/PRIVACY_POLICY.md"
}