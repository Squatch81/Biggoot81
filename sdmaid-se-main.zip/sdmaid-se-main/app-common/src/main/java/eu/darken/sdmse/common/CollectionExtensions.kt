package eu.darken.sdmse.common

fun <T> Collection<T>?.isNotNullOrEmpty() = !isNullOrEmpty()