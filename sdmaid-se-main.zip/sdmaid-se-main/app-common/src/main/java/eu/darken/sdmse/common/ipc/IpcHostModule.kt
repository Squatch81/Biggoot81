package eu.darken.sdmse.common.ipc

interface IpcHostModule