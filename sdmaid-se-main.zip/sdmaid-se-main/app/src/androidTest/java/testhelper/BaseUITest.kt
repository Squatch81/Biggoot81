package testhelper

abstract class BaseUITest : BaseTestInstrumentation()
