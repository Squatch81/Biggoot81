package eu.darken.sdmse.common.pkgs.pkgops

class IllegalPkgDataException(
    override val message: String
) : IllegalStateException()