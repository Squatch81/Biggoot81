package testhelper

import android.app.Application

class EmptyApp : Application()